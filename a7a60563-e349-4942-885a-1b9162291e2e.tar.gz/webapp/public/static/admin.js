// Admin Panel JavaScript for Om Modular Araria

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
  // Check admin authentication
  const adminToken = localStorage.getItem('admin_token');
  
  if (!adminToken) {
    // Show login form
    showAdminLogin();
  } else {
    // Load admin dashboard
    loadAdminDashboard();
  }
});

// Show admin login form
function showAdminLogin() {
  const app = document.getElementById('admin_app');
  app.innerHTML = `
    <div class="min-h-screen flex items-center justify-center bg-gray-100">
      <div class="bg-white p-8 rounded-lg shadow-lg w-96">
        <h2 class="text-2xl font-bold mb-6 text-center">Admin Login</h2>
        <form onsubmit="handleAdminLogin(event)">
          <div class="mb-4">
            <label class="block text-gray-700 mb-2">Username or Email</label>
            <input type="text" id="admin_username" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500" required>
          </div>
          <div class="mb-6">
            <label class="block text-gray-700 mb-2">Password</label>
            <input type="password" id="admin_password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500" required>
          </div>
          <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
            Login
          </button>
        </form>
      </div>
    </div>
  `;
}

// Handle admin login
async function handleAdminLogin(event) {
  event.preventDefault();
  
  const username = document.getElementById('admin_username').value;
  const password = document.getElementById('admin_password').value;
  
  try {
    const response = await fetch('/api/auth/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });
    
    if (response.ok) {
      const data = await response.json();
      localStorage.setItem('admin_token', data.token);
      localStorage.setItem('admin_user', JSON.stringify(data.admin));
      loadAdminDashboard();
    } else {
      alert('Invalid credentials');
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('Login failed');
  }
}

// Load admin dashboard
async function loadAdminDashboard() {
  const app = document.getElementById('admin_app');
  const adminUser = JSON.parse(localStorage.getItem('admin_user'));
  
  app.innerHTML = `
    <div class="min-h-screen bg-gray-100">
      <!-- Sidebar -->
      <div class="fixed inset-y-0 left-0 w-64 bg-black text-white">
        <div class="p-4 border-b border-gray-800">
          <h2 class="text-xl font-bold">Admin Panel</h2>
          <p class="text-sm text-gray-400">Om Modular Araria</p>
        </div>
        <nav class="p-4">
          <a href="#dashboard" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadDashboard()">
            <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
          </a>
          <a href="#products" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadProducts()">
            <i class="fas fa-box mr-2"></i> Products
          </a>
          <a href="#orders" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadOrders()">
            <i class="fas fa-shopping-cart mr-2"></i> Orders
          </a>
          <a href="#customers" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadCustomers()">
            <i class="fas fa-users mr-2"></i> Customers
          </a>
          <a href="#categories" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadCategories()">
            <i class="fas fa-list mr-2"></i> Categories
          </a>
          <a href="#settings" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadSettings()">
            <i class="fas fa-cog mr-2"></i> Settings
          </a>
          <a href="#seo" class="block py-2 px-4 hover:bg-gray-800 rounded" onclick="loadSEO()">
            <i class="fas fa-search mr-2"></i> SEO
          </a>
          <a href="#" class="block py-2 px-4 hover:bg-gray-800 rounded mt-8" onclick="adminLogout()">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
          </a>
        </nav>
      </div>
      
      <!-- Main Content -->
      <div class="ml-64">
        <!-- Header -->
        <header class="bg-white shadow-sm p-4">
          <div class="flex justify-between items-center">
            <h1 class="text-2xl font-bold" id="page_title">Dashboard</h1>
            <div class="flex items-center">
              <span class="mr-4">Welcome, ${adminUser.full_name}</span>
              <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                <i class="fas fa-plus mr-2"></i> Add New
              </button>
            </div>
          </div>
        </header>
        
        <!-- Content Area -->
        <main class="p-6" id="admin_content">
          <!-- Dynamic content loaded here -->
        </main>
      </div>
    </div>
  `;
  
  // Load initial dashboard
  loadDashboard();
}

// Load dashboard stats
async function loadDashboard() {
  document.getElementById('page_title').textContent = 'Dashboard';
  const content = document.getElementById('admin_content');
  
  try {
    const response = await fetch('/api/admin/dashboard', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('admin_token')}`
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      
      content.innerHTML = `
        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Today's Orders</div>
            <div class="text-3xl font-bold text-blue-600">${data.stats.todayOrders}</div>
          </div>
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Today's Revenue</div>
            <div class="text-3xl font-bold text-green-600">₹${data.stats.todayRevenue?.toLocaleString() || 0}</div>
          </div>
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Total Customers</div>
            <div class="text-3xl font-bold text-purple-600">${data.stats.totalCustomers}</div>
          </div>
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Active Products</div>
            <div class="text-3xl font-bold text-indigo-600">${data.stats.activeProducts}</div>
          </div>
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Pending Orders</div>
            <div class="text-3xl font-bold text-yellow-600">${data.stats.pendingOrders}</div>
          </div>
          <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Low Stock</div>
            <div class="text-3xl font-bold text-red-600">${data.stats.lowStockProducts}</div>
          </div>
        </div>
        
        <!-- Recent Orders -->
        <div class="bg-white rounded-lg shadow p-6">
          <h2 class="text-xl font-bold mb-4">Recent Orders</h2>
          <table class="w-full">
            <thead>
              <tr class="border-b">
                <th class="text-left py-2">Order #</th>
                <th class="text-left py-2">Customer</th>
                <th class="text-left py-2">Amount</th>
                <th class="text-left py-2">Status</th>
                <th class="text-left py-2">Date</th>
                <th class="text-left py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${data.recentOrders.map(order => `
                <tr class="border-b hover:bg-gray-50">
                  <td class="py-2">${order.order_number}</td>
                  <td class="py-2">${order.guest_email || 'Customer'}</td>
                  <td class="py-2">₹${order.total_amount.toLocaleString()}</td>
                  <td class="py-2">
                    <span class="px-2 py-1 text-xs rounded ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                      order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }">${order.status}</span>
                  </td>
                  <td class="py-2">${new Date(order.created_at).toLocaleDateString()}</td>
                  <td class="py-2">
                    <button class="text-blue-600 hover:underline">View</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }
  } catch (error) {
    console.error('Error loading dashboard:', error);
    content.innerHTML = '<p class="text-red-500">Error loading dashboard</p>';
  }
}

// Load products management
async function loadProducts() {
  document.getElementById('page_title').textContent = 'Products Management';
  const content = document.getElementById('admin_content');
  
  content.innerHTML = `
    <div class="bg-white rounded-lg shadow p-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold">All Products</h2>
        <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
          <i class="fas fa-plus mr-2"></i> Add Product
        </button>
      </div>
      <p class="text-gray-600">Product management interface will be loaded here...</p>
    </div>
  `;
}

// Admin logout
function adminLogout() {
  localStorage.removeItem('admin_token');
  localStorage.removeItem('admin_user');
  window.location.href = '/admin';
}