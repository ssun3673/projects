// Main JavaScript for Om Modular Araria E-commerce

// Global variables
let currentUser = null;
let cartItems = [];
let wishlistItems = [];
let sessionId = localStorage.getItem('session_id') || generateSessionId();

// Generate session ID
function generateSessionId() {
  const id = 'sess_' + Date.now() + '_' + Math.random().toString(36).substring(7);
  localStorage.setItem('session_id', id);
  return id;
}

// Check user session
async function checkUserSession() {
  const token = localStorage.getItem('auth_token');
  if (token) {
    try {
      const response = await fetch('/api/auth/verify', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        currentUser = await response.json();
        updateUserInterface();
      } else {
        localStorage.removeItem('auth_token');
        currentUser = null;
      }
    } catch (error) {
      console.error('Session check failed:', error);
    }
  }
}

// Update user interface based on login status
function updateUserInterface() {
  const accountBtn = document.querySelector('[onclick="toggleLogin()"]');
  if (currentUser) {
    accountBtn.innerHTML = `
      <i class="fas fa-user-check text-xl mb-1"></i>
      <span class="text-xs">Hi, ${currentUser.first_name}</span>
    `;
  }
}

// Load homepage data
async function loadHomepageData() {
  try {
    // Load banner/slider
    loadHeroSlider();
    
    // Load categories
    loadCategories();
    
    // Load featured products
    loadFeaturedProducts();
    
  } catch (error) {
    console.error('Error loading homepage:', error);
  }
}

// Load hero slider
async function loadHeroSlider() {
  const sliderHtml = `
    <div class="relative h-full overflow-hidden">
      <div class="flex transition-transform duration-500" id="slider_track">
        <div class="w-full h-full flex-shrink-0 bg-gradient-to-r from-blue-600 to-blue-400 flex items-center">
          <div class="container mx-auto px-4 text-white">
            <h2 class="text-5xl font-bold mb-4">Premium Modular Furniture</h2>
            <p class="text-xl mb-6">Transform your space with our exclusive collection</p>
            <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100">
              Shop Now
            </button>
          </div>
        </div>
        <div class="w-full h-full flex-shrink-0 bg-gradient-to-r from-pink-500 to-pink-400 flex items-center">
          <div class="container mx-auto px-4 text-white">
            <h2 class="text-5xl font-bold mb-4">Flat 20% OFF</h2>
            <p class="text-xl mb-6">On all furniture - Limited time offer!</p>
            <button class="bg-white text-pink-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100">
              Grab Deal
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  document.getElementById('hero_slider').innerHTML = sliderHtml;
  
  // Auto-slide
  let currentSlide = 0;
  setInterval(() => {
    currentSlide = (currentSlide + 1) % 2;
    document.getElementById('slider_track').style.transform = `translateX(-${currentSlide * 100}%)`;
  }, 5000);
}

// Load categories
async function loadCategories() {
  try {
    const response = await fetch('/api/products/categories');
    const data = await response.json();
    
    const mainCategories = data.categories.filter(c => !c.parent_id).slice(0, 8);
    
    const categoryGrid = document.getElementById('category_grid');
    categoryGrid.innerHTML = mainCategories.map(category => `
      <a href="/category/${category.slug}" class="group cursor-pointer">
        <div class="bg-white rounded-lg p-6 text-center hover:shadow-lg transition">
          <div class="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200">
            <i class="fas fa-couch text-3xl text-blue-600"></i>
          </div>
          <h3 class="font-semibold">${category.name}</h3>
        </div>
      </a>
    `).join('');
  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

// Load featured products
async function loadFeaturedProducts() {
  try {
    const response = await fetch('/api/products?featured=true&limit=8');
    const data = await response.json();
    
    const productsGrid = document.getElementById('featured_products');
    productsGrid.innerHTML = data.products.map(product => {
      const images = JSON.parse(product.images || '[]');
      const price = product.sale_price || product.price;
      const originalPrice = product.sale_price ? product.price : null;
      
      return `
        <div class="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition cursor-pointer" onclick="viewProduct('${product.slug}')">
          <div class="relative">
            <img src="${images[0] || '/images/placeholder.jpg'}" alt="${product.name}" class="w-full h-48 object-cover">
            ${product.sale_price ? '<span class="absolute top-2 left-2 bg-pink-500 text-white px-2 py-1 text-xs rounded">SALE</span>' : ''}
            ${product.is_new ? '<span class="absolute top-2 right-2 bg-blue-600 text-white px-2 py-1 text-xs rounded">NEW</span>' : ''}
            <button onclick="event.stopPropagation(); toggleWishlist(${product.id})" class="absolute bottom-2 right-2 bg-white p-2 rounded-full shadow hover:bg-pink-50">
              <i class="far fa-heart text-pink-500"></i>
            </button>
          </div>
          <div class="p-4">
            <h3 class="font-semibold mb-2 truncate">${product.name}</h3>
            <div class="flex items-center justify-between mb-3">
              <div>
                <span class="text-xl font-bold text-blue-600">₹${price.toLocaleString()}</span>
                ${originalPrice ? `<span class="text-sm text-gray-500 line-through ml-2">₹${originalPrice.toLocaleString()}</span>` : ''}
              </div>
              ${product.rating_average > 0 ? `
                <div class="text-yellow-500 text-sm">
                  <i class="fas fa-star"></i> ${product.rating_average}
                </div>
              ` : ''}
            </div>
            <button onclick="event.stopPropagation(); addToCart(${product.id})" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
              <i class="fas fa-shopping-cart mr-2"></i> Add to Cart
            </button>
          </div>
        </div>
      `;
    }).join('');
  } catch (error) {
    console.error('Error loading featured products:', error);
  }
}

// Search products
function searchProducts(event) {
  event.preventDefault();
  const query = document.getElementById('search_input').value;
  if (query) {
    window.location.href = `/search?q=${encodeURIComponent(query)}`;
  }
}

// View product details
function viewProduct(slug) {
  window.location.href = `/product/${slug}`;
}

// Add to cart
async function addToCart(productId, quantity = 1) {
  try {
    const response = await fetch('/api/cart/add', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Session-Id': sessionId,
        'X-Customer-Id': currentUser?.id || ''
      },
      body: JSON.stringify({ product_id: productId, quantity })
    });
    
    if (response.ok) {
      showNotification('Product added to cart!', 'success');
      updateCartCount();
    } else {
      showNotification('Failed to add to cart', 'error');
    }
  } catch (error) {
    console.error('Error adding to cart:', error);
    showNotification('Error adding to cart', 'error');
  }
}

// Update cart count
async function updateCartCount() {
  try {
    const response = await fetch('/api/cart', {
      headers: {
        'X-Session-Id': sessionId,
        'X-Customer-Id': currentUser?.id || ''
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      const cartCount = data.items.length;
      document.querySelector('[onclick="toggleCart()"] .absolute').textContent = cartCount;
    }
  } catch (error) {
    console.error('Error updating cart count:', error);
  }
}

// Toggle cart
function toggleCart() {
  window.location.href = '/cart';
}

// Toggle wishlist
async function toggleWishlist(productId) {
  if (!currentUser) {
    showNotification('Please login to add to wishlist', 'warning');
    return;
  }
  
  try {
    const response = await fetch('/api/customer/wishlist', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
      },
      body: JSON.stringify({ 
        customer_id: currentUser.id, 
        product_id: productId 
      })
    });
    
    if (response.ok) {
      showNotification('Added to wishlist!', 'success');
      updateWishlistCount();
    }
  } catch (error) {
    console.error('Error adding to wishlist:', error);
  }
}

// Update wishlist count
async function updateWishlistCount() {
  if (!currentUser) return;
  
  try {
    const response = await fetch(`/api/customer/wishlist/${currentUser.id}`);
    if (response.ok) {
      const data = await response.json();
      document.querySelector('[onclick="toggleWishlist()"] .absolute').textContent = data.wishlist.length;
    }
  } catch (error) {
    console.error('Error updating wishlist count:', error);
  }
}

// Toggle login modal
function toggleLogin() {
  if (currentUser) {
    window.location.href = '/account';
  } else {
    window.location.href = '/login';
  }
}

// Show notification
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg text-white ${
    type === 'success' ? 'bg-green-500' :
    type === 'error' ? 'bg-red-500' :
    type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
  }`;
  notification.innerHTML = `
    <div class="flex items-center">
      <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} mr-2"></i>
      <span>${message}</span>
    </div>
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 500);
  }, 3000);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  checkUserSession();
  updateCartCount();
  if (currentUser) {
    updateWishlistCount();
  }
});