// Password hashing utilities using Web Crypto API for Cloudflare Workers

export async function hashPassword(password: string): Promise<string> {
  // Use Web Crypto API for password hashing
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  
  // Generate salt
  const salt = crypto.getRandomValues(new Uint8Array(16))
  
  // Combine password with salt
  const combined = new Uint8Array(salt.length + data.length)
  combined.set(salt)
  combined.set(data, salt.length)
  
  // Hash using SHA-256
  const hashBuffer = await crypto.subtle.digest('SHA-256', combined)
  const hashArray = new Uint8Array(hashBuffer)
  
  // Combine salt and hash for storage
  const result = new Uint8Array(salt.length + hashArray.length)
  result.set(salt)
  result.set(hashArray, salt.length)
  
  // Convert to base64 for storage
  return btoa(String.fromCharCode.apply(null, Array.from(result)))
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  try {
    // Decode the stored hash
    const stored = Uint8Array.from(atob(storedHash), c => c.charCodeAt(0))
    
    // Extract salt (first 16 bytes)
    const salt = stored.slice(0, 16)
    const storedHashPart = stored.slice(16)
    
    // Hash the provided password with the same salt
    const encoder = new TextEncoder()
    const data = encoder.encode(password)
    
    const combined = new Uint8Array(salt.length + data.length)
    combined.set(salt)
    combined.set(data, salt.length)
    
    const hashBuffer = await crypto.subtle.digest('SHA-256', combined)
    const hashArray = new Uint8Array(hashBuffer)
    
    // Compare hashes
    if (hashArray.length !== storedHashPart.length) return false
    
    for (let i = 0; i < hashArray.length; i++) {
      if (hashArray[i] !== storedHashPart[i]) return false
    }
    
    return true
  } catch (error) {
    console.error('Password verification error:', error)
    return false
  }
}

// Generate JWT token using Web Crypto API
export async function generateToken(payload: any, secret: string): Promise<string> {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  }
  
  const encodedHeader = btoa(JSON.stringify(header)).replace(/=/g, '')
  const encodedPayload = btoa(JSON.stringify(payload)).replace(/=/g, '')
  
  const data = `${encodedHeader}.${encodedPayload}`
  
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  
  const signature = await crypto.subtle.sign(
    'HMAC',
    key,
    encoder.encode(data)
  )
  
  const encodedSignature = btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(signature)))).replace(/=/g, '')
  
  return `${data}.${encodedSignature}`
}