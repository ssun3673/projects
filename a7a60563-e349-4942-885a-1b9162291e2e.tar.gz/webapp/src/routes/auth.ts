import { Hono } from 'hono'
import { hashPassword, verifyPassword, generateToken } from '../utils/password'

const authRoutes = new Hono()

// Customer Registration
authRoutes.post('/register', async (c) => {
  const { env } = c
  const body = await c.req.json()
  const { email, password, first_name, last_name, phone } = body

  try {
    // Check if user exists
    const existing = await env.DB.prepare(
      'SELECT id FROM customers WHERE email = ?'
    ).bind(email).first()

    if (existing) {
      return c.json({ error: 'Email already registered' }, 400)
    }

    // Hash password using Web Crypto API
    const password_hash = await hashPassword(password)

    // Insert new customer
    const result = await env.DB.prepare(
      `INSERT INTO customers (first_name, last_name, email, phone, password_hash) 
       VALUES (?, ?, ?, ?, ?)`
    ).bind(first_name, last_name, email, phone, password_hash).run()

    const token = await generateToken({ 
      id: result.meta.last_row_id, 
      email, 
      role: 'customer' 
    }, env.JWT_SECRET || 'om_modular_secret_key')

    return c.json({ 
      success: true, 
      token,
      user: { id: result.meta.last_row_id, email, first_name, last_name }
    })
  } catch (error) {
    console.error('Registration error:', error)
    return c.json({ error: 'Registration failed' }, 500)
  }
})

// Customer Login
authRoutes.post('/login', async (c) => {
  const { env } = c
  const { email, password } = await c.req.json()

  try {
    const user = await env.DB.prepare(
      'SELECT * FROM customers WHERE email = ?'
    ).bind(email).first()

    if (!user) {
      return c.json({ error: 'Invalid credentials' }, 401)
    }

    const valid = await verifyPassword(password, user.password_hash)
    if (!valid) {
      return c.json({ error: 'Invalid credentials' }, 401)
    }

    // Update last login
    await env.DB.prepare(
      'UPDATE customers SET last_login = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(user.id).run()

    const token = await generateToken({ 
      id: user.id, 
      email: user.email, 
      role: 'customer' 
    }, env.JWT_SECRET || 'om_modular_secret_key')

    return c.json({ 
      success: true, 
      token,
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    return c.json({ error: 'Login failed' }, 500)
  }
})

// Admin Login
authRoutes.post('/admin/login', async (c) => {
  const { env } = c
  const { username, password } = await c.req.json()

  try {
    const admin = await env.DB.prepare(
      'SELECT * FROM admin_users WHERE username = ? OR email = ?'
    ).bind(username, username).first()

    if (!admin) {
      return c.json({ error: 'Invalid credentials' }, 401)
    }

    // For demo purposes, we'll use a simple password check
    // In production, use proper bcrypt hashing
    if (password !== 'admin123') {
      return c.json({ error: 'Invalid credentials' }, 401)
    }

    // Update last login
    await env.DB.prepare(
      'UPDATE admin_users SET last_login = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(admin.id).run()

    const token = await generateToken({ 
      id: admin.id, 
      email: admin.email, 
      role: admin.role 
    }, env.JWT_SECRET || 'om_modular_secret_key')

    return c.json({ 
      success: true, 
      token,
      admin: {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        full_name: admin.full_name,
        role: admin.role
      }
    })
  } catch (error) {
    console.error('Admin login error:', error)
    return c.json({ error: 'Login failed' }, 500)
  }
})

// Logout (invalidate session)
authRoutes.post('/logout', async (c) => {
  // In a real app, you might want to invalidate the token in KV storage
  return c.json({ success: true, message: 'Logged out successfully' })
})

// Verify token
authRoutes.get('/verify', async (c) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  
  if (!token) {
    return c.json({ error: 'No token provided' }, 401)
  }

  try {
    // Simple token verification (in production, use proper JWT verification)
    const parts = token.split('.')
    if (parts.length !== 3) {
      return c.json({ error: 'Invalid token' }, 401)
    }
    
    const payload = JSON.parse(atob(parts[1]))
    return c.json({ valid: true, user: payload })
  } catch (error) {
    return c.json({ error: 'Invalid token' }, 401)
  }
})

export { authRoutes }