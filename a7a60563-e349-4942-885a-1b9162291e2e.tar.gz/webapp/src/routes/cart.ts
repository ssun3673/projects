import { Hono } from 'hono'

const cartRoutes = new Hono()

// Get cart items
cartRoutes.get('/', async (c) => {
  const { env } = c
  const session_id = c.req.header('X-Session-Id')
  const customer_id = c.req.header('X-Customer-Id')

  try {
    let query = `
      SELECT ci.*, p.name, p.slug, p.price, p.sale_price, p.images, p.quantity as stock
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE `
    
    const params = []
    
    if (customer_id) {
      query += 'ci.customer_id = ?'
      params.push(customer_id)
    } else {
      query += 'ci.session_id = ?'
      params.push(session_id)
    }

    const items = await env.DB.prepare(query).bind(...params).all()

    // Calculate totals
    let subtotal = 0
    const cartItems = items.results?.map((item: any) => {
      const price = item.sale_price || item.price
      const total = price * item.quantity
      subtotal += total
      return {
        ...item,
        unit_price: price,
        total
      }
    })

    return c.json({
      items: cartItems || [],
      subtotal,
      shipping: subtotal >= 5000 ? 0 : 500,
      tax: subtotal * 0.18, // 18% GST
      total: subtotal + (subtotal >= 5000 ? 0 : 500) + (subtotal * 0.18)
    })
  } catch (error) {
    console.error('Error fetching cart:', error)
    return c.json({ error: 'Failed to fetch cart' }, 500)
  }
})

// Add to cart
cartRoutes.post('/add', async (c) => {
  const { env } = c
  const { product_id, quantity = 1 } = await c.req.json()
  const session_id = c.req.header('X-Session-Id')
  const customer_id = c.req.header('X-Customer-Id')

  try {
    // Check product availability
    const product = await env.DB.prepare(
      'SELECT * FROM products WHERE id = ? AND status = "active"'
    ).bind(product_id).first()

    if (!product) {
      return c.json({ error: 'Product not found' }, 404)
    }

    if (product.quantity < quantity) {
      return c.json({ error: 'Insufficient stock' }, 400)
    }

    // Check if item exists in cart
    let existingQuery = 'SELECT * FROM cart_items WHERE product_id = ? AND '
    const existingParams = [product_id]
    
    if (customer_id) {
      existingQuery += 'customer_id = ?'
      existingParams.push(customer_id)
    } else {
      existingQuery += 'session_id = ?'
      existingParams.push(session_id)
    }

    const existing = await env.DB.prepare(existingQuery).bind(...existingParams).first()

    if (existing) {
      // Update quantity
      await env.DB.prepare(
        'UPDATE cart_items SET quantity = quantity + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
      ).bind(quantity, existing.id).run()
    } else {
      // Insert new item
      await env.DB.prepare(
        'INSERT INTO cart_items (session_id, customer_id, product_id, quantity) VALUES (?, ?, ?, ?)'
      ).bind(session_id, customer_id || null, product_id, quantity).run()
    }

    return c.json({ success: true, message: 'Added to cart' })
  } catch (error) {
    console.error('Error adding to cart:', error)
    return c.json({ error: 'Failed to add to cart' }, 500)
  }
})

// Update cart item quantity
cartRoutes.put('/update', async (c) => {
  const { env } = c
  const { cart_item_id, quantity } = await c.req.json()

  try {
    if (quantity <= 0) {
      // Remove item
      await env.DB.prepare(
        'DELETE FROM cart_items WHERE id = ?'
      ).bind(cart_item_id).run()
    } else {
      // Update quantity
      await env.DB.prepare(
        'UPDATE cart_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
      ).bind(quantity, cart_item_id).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating cart:', error)
    return c.json({ error: 'Failed to update cart' }, 500)
  }
})

// Remove from cart
cartRoutes.delete('/:id', async (c) => {
  const { env } = c
  const cart_item_id = c.req.param('id')

  try {
    await env.DB.prepare(
      'DELETE FROM cart_items WHERE id = ?'
    ).bind(cart_item_id).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error removing from cart:', error)
    return c.json({ error: 'Failed to remove from cart' }, 500)
  }
})

// Clear cart
cartRoutes.post('/clear', async (c) => {
  const { env } = c
  const session_id = c.req.header('X-Session-Id')
  const customer_id = c.req.header('X-Customer-Id')

  try {
    if (customer_id) {
      await env.DB.prepare(
        'DELETE FROM cart_items WHERE customer_id = ?'
      ).bind(customer_id).run()
    } else {
      await env.DB.prepare(
        'DELETE FROM cart_items WHERE session_id = ?'
      ).bind(session_id).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error clearing cart:', error)
    return c.json({ error: 'Failed to clear cart' }, 500)
  }
})

export { cartRoutes }