import { Hono } from 'hono'
import { v4 as uuidv4 } from 'uuid'

const orderRoutes = new Hono()

// Create order
orderRoutes.post('/create', async (c) => {
  const { env } = c
  const body = await c.req.json()
  const {
    customer_id,
    guest_email,
    guest_phone,
    cart_items,
    shipping_address,
    billing_address,
    payment_method,
    coupon_code,
    notes
  } = body

  try {
    // Generate order number
    const order_number = 'ORD' + Date.now()

    // Calculate totals
    let subtotal = 0
    for (const item of cart_items) {
      const product = await env.DB.prepare(
        'SELECT price, sale_price FROM products WHERE id = ?'
      ).bind(item.product_id).first()
      
      const price = product.sale_price || product.price
      subtotal += price * item.quantity
    }

    const tax_amount = subtotal * 0.18 // 18% GST
    const shipping_amount = subtotal >= 5000 ? 0 : 500
    let discount_amount = 0

    // Apply coupon if provided
    if (coupon_code) {
      const coupon = await env.DB.prepare(
        'SELECT * FROM coupons WHERE code = ? AND is_active = 1'
      ).bind(coupon_code).first()

      if (coupon && subtotal >= coupon.min_order_amount) {
        if (coupon.discount_type === 'percentage') {
          discount_amount = (subtotal * coupon.discount_value) / 100
          if (coupon.max_discount_amount && discount_amount > coupon.max_discount_amount) {
            discount_amount = coupon.max_discount_amount
          }
        } else {
          discount_amount = coupon.discount_value
        }

        // Update coupon usage
        await env.DB.prepare(
          'UPDATE coupons SET usage_count = usage_count + 1 WHERE id = ?'
        ).bind(coupon.id).run()
      }
    }

    const total_amount = subtotal + tax_amount + shipping_amount - discount_amount

    // Insert order
    const orderResult = await env.DB.prepare(
      `INSERT INTO orders (
        order_number, customer_id, guest_email, guest_phone,
        status, payment_status, payment_method,
        subtotal, tax_amount, shipping_amount, discount_amount, total_amount,
        coupon_code, shipping_address, billing_address, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      order_number,
      customer_id || null,
      guest_email || null,
      guest_phone || null,
      'pending',
      'pending',
      payment_method,
      subtotal,
      tax_amount,
      shipping_amount,
      discount_amount,
      total_amount,
      coupon_code || null,
      JSON.stringify(shipping_address),
      JSON.stringify(billing_address || shipping_address),
      notes || null
    ).run()

    const order_id = orderResult.meta.last_row_id

    // Insert order items
    for (const item of cart_items) {
      const product = await env.DB.prepare(
        'SELECT name, sku, images, price, sale_price FROM products WHERE id = ?'
      ).bind(item.product_id).first()

      const price = product.sale_price || product.price
      const images = JSON.parse(product.images || '[]')

      await env.DB.prepare(
        `INSERT INTO order_items (
          order_id, product_id, product_name, product_sku, product_image,
          quantity, price, total
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        order_id,
        item.product_id,
        product.name,
        product.sku,
        images[0] || null,
        item.quantity,
        price,
        price * item.quantity
      ).run()

      // Update product stock
      await env.DB.prepare(
        'UPDATE products SET quantity = quantity - ? WHERE id = ?'
      ).bind(item.quantity, item.product_id).run()
    }

    // Clear cart
    if (customer_id) {
      await env.DB.prepare(
        'DELETE FROM cart_items WHERE customer_id = ?'
      ).bind(customer_id).run()
    }

    return c.json({
      success: true,
      order_id,
      order_number,
      total_amount,
      payment_method
    })
  } catch (error) {
    console.error('Error creating order:', error)
    return c.json({ error: 'Failed to create order' }, 500)
  }
})

// Get order details
orderRoutes.get('/:order_number', async (c) => {
  const { env } = c
  const order_number = c.req.param('order_number')

  try {
    const order = await env.DB.prepare(
      'SELECT * FROM orders WHERE order_number = ?'
    ).bind(order_number).first()

    if (!order) {
      return c.json({ error: 'Order not found' }, 404)
    }

    const items = await env.DB.prepare(
      'SELECT * FROM order_items WHERE order_id = ?'
    ).bind(order.id).all()

    return c.json({
      order: {
        ...order,
        shipping_address: JSON.parse(order.shipping_address || '{}'),
        billing_address: JSON.parse(order.billing_address || '{}')
      },
      items: items.results
    })
  } catch (error) {
    console.error('Error fetching order:', error)
    return c.json({ error: 'Failed to fetch order' }, 500)
  }
})

// Get customer orders
orderRoutes.get('/customer/:customer_id', async (c) => {
  const { env } = c
  const customer_id = c.req.param('customer_id')

  try {
    const orders = await env.DB.prepare(
      'SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC'
    ).bind(customer_id).all()

    return c.json({ orders: orders.results })
  } catch (error) {
    console.error('Error fetching orders:', error)
    return c.json({ error: 'Failed to fetch orders' }, 500)
  }
})

// Update order status (webhook from payment gateway)
orderRoutes.post('/update-payment', async (c) => {
  const { env } = c
  const { order_number, payment_id, transaction_id, status } = await c.req.json()

  try {
    await env.DB.prepare(
      `UPDATE orders 
       SET payment_status = ?, payment_id = ?, transaction_id = ?, 
           status = CASE WHEN ? = 'paid' THEN 'processing' ELSE status END
       WHERE order_number = ?`
    ).bind(status, payment_id, transaction_id, status, order_number).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating payment:', error)
    return c.json({ error: 'Failed to update payment' }, 500)
  }
})

// Track order
orderRoutes.get('/track/:order_number', async (c) => {
  const { env } = c
  const order_number = c.req.param('order_number')

  try {
    const order = await env.DB.prepare(
      'SELECT order_number, status, tracking_number, created_at, shipped_at, delivered_at FROM orders WHERE order_number = ?'
    ).bind(order_number).first()

    if (!order) {
      return c.json({ error: 'Order not found' }, 404)
    }

    return c.json({ order })
  } catch (error) {
    console.error('Error tracking order:', error)
    return c.json({ error: 'Failed to track order' }, 500)
  }
})

export { orderRoutes }