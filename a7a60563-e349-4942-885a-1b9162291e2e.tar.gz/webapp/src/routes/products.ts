import { Hono } from 'hono'

const productRoutes = new Hono()

// Get all products with filters
productRoutes.get('/', async (c) => {
  const { env } = c
  const { 
    category, 
    min_price, 
    max_price, 
    sort, 
    search,
    featured,
    page = '1',
    limit = '12' 
  } = c.req.query()

  let query = 'SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = "active"'
  const params: any[] = []

  // Add filters
  if (category) {
    query += ' AND c.slug = ?'
    params.push(category)
  }
  
  if (min_price) {
    query += ' AND p.price >= ?'
    params.push(min_price)
  }
  
  if (max_price) {
    query += ' AND p.price <= ?'
    params.push(max_price)
  }

  if (featured === 'true') {
    query += ' AND p.featured = 1'
  }

  if (search) {
    query += ' AND (p.name LIKE ? OR p.description LIKE ?)'
    params.push(`%${search}%`, `%${search}%`)
  }

  // Add sorting
  switch(sort) {
    case 'price_asc':
      query += ' ORDER BY p.price ASC'
      break
    case 'price_desc':
      query += ' ORDER BY p.price DESC'
      break
    case 'name':
      query += ' ORDER BY p.name ASC'
      break
    case 'newest':
      query += ' ORDER BY p.created_at DESC'
      break
    default:
      query += ' ORDER BY p.featured DESC, p.created_at DESC'
  }

  // Add pagination
  const offset = (parseInt(page) - 1) * parseInt(limit)
  query += ' LIMIT ? OFFSET ?'
  params.push(parseInt(limit), offset)

  try {
    const products = await env.DB.prepare(query).bind(...params).all()
    
    // Get total count for pagination
    let countQuery = 'SELECT COUNT(*) as total FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = "active"'
    const countParams: any[] = []
    
    if (category) {
      countQuery += ' AND c.slug = ?'
      countParams.push(category)
    }
    
    const totalResult = await env.DB.prepare(countQuery).bind(...countParams).first()
    const total = totalResult?.total || 0

    return c.json({
      products: products.results,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    })
  } catch (error) {
    console.error('Error fetching products:', error)
    return c.json({ error: 'Failed to fetch products' }, 500)
  }
})

// Get single product
productRoutes.get('/:slug', async (c) => {
  const { env } = c
  const slug = c.req.param('slug')

  try {
    const product = await env.DB.prepare(
      `SELECT p.*, c.name as category_name, c.slug as category_slug 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.id 
       WHERE p.slug = ?`
    ).bind(slug).first()

    if (!product) {
      return c.json({ error: 'Product not found' }, 404)
    }

    // Update view count
    await env.DB.prepare(
      'UPDATE products SET views = views + 1 WHERE id = ?'
    ).bind(product.id).run()

    // Get related products
    const related = await env.DB.prepare(
      `SELECT * FROM products 
       WHERE category_id = ? AND id != ? AND status = "active" 
       LIMIT 4`
    ).bind(product.category_id, product.id).all()

    // Get reviews
    const reviews = await env.DB.prepare(
      `SELECT r.*, c.first_name, c.last_name 
       FROM reviews r 
       LEFT JOIN customers c ON r.customer_id = c.id 
       WHERE r.product_id = ? AND r.is_approved = 1 
       ORDER BY r.created_at DESC 
       LIMIT 10`
    ).bind(product.id).all()

    return c.json({
      product,
      related: related.results,
      reviews: reviews.results
    })
  } catch (error) {
    console.error('Error fetching product:', error)
    return c.json({ error: 'Failed to fetch product' }, 500)
  }
})

// Get featured products
productRoutes.get('/featured', async (c) => {
  const { env } = c

  try {
    const products = await env.DB.prepare(
      'SELECT * FROM products WHERE featured = 1 AND status = "active" LIMIT 8'
    ).all()

    return c.json({ products: products.results })
  } catch (error) {
    console.error('Error fetching featured products:', error)
    return c.json({ error: 'Failed to fetch featured products' }, 500)
  }
})

// Get categories
productRoutes.get('/categories', async (c) => {
  const { env } = c

  try {
    const categories = await env.DB.prepare(
      'SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name'
    ).all()

    return c.json({ categories: categories.results })
  } catch (error) {
    console.error('Error fetching categories:', error)
    return c.json({ error: 'Failed to fetch categories' }, 500)
  }
})

// Add product review
productRoutes.post('/:id/reviews', async (c) => {
  const { env } = c
  const productId = c.req.param('id')
  const { rating, title, comment, customer_id, order_id } = await c.req.json()

  try {
    // Check if customer has purchased this product
    const orderCheck = await env.DB.prepare(
      `SELECT COUNT(*) as count FROM order_items oi 
       JOIN orders o ON oi.order_id = o.id 
       WHERE oi.product_id = ? AND o.customer_id = ? AND o.status = "delivered"`
    ).bind(productId, customer_id).first()

    const is_verified_purchase = orderCheck?.count > 0

    // Insert review
    const result = await env.DB.prepare(
      `INSERT INTO reviews (product_id, customer_id, order_id, rating, title, comment, is_verified_purchase, is_approved) 
       VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
    ).bind(productId, customer_id, order_id || null, rating, title, comment, is_verified_purchase ? 1 : 0).run()

    // Update product rating
    await env.DB.prepare(
      `UPDATE products 
       SET rating_average = (SELECT AVG(rating) FROM reviews WHERE product_id = ? AND is_approved = 1),
           rating_count = (SELECT COUNT(*) FROM reviews WHERE product_id = ? AND is_approved = 1)
       WHERE id = ?`
    ).bind(productId, productId, productId).run()

    return c.json({ success: true, review_id: result.meta.last_row_id })
  } catch (error) {
    console.error('Error adding review:', error)
    return c.json({ error: 'Failed to add review' }, 500)
  }
})

export { productRoutes }