import { Hono } from 'hono'

const paymentRoutes = new Hono()

// Helper function to create HMAC signature using Web Crypto API
async function createHmacSignature(secret: string, data: string): Promise<string> {
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  
  const signature = await crypto.subtle.sign(
    'HMAC',
    key,
    encoder.encode(data)
  )
  
  return Array.from(new Uint8Array(signature))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

// Helper function for SHA256 hash
async function sha256Hash(data: string): Promise<string> {
  const encoder = new TextEncoder()
  const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(data))
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

// Initialize Razorpay payment
paymentRoutes.post('/razorpay/create', async (c) => {
  const { env } = c
  const { order_id, amount } = await c.req.json()

  try {
    // Get Razorpay credentials from settings
    const settings = await env.DB.prepare(
      `SELECT setting_key, setting_value FROM site_settings 
       WHERE setting_key IN ('razorpay_key_id', 'razorpay_key_secret')`
    ).all()

    const razorpay_key_id = settings.results?.find((s: any) => s.setting_key === 'razorpay_key_id')?.setting_value
    const razorpay_key_secret = settings.results?.find((s: any) => s.setting_key === 'razorpay_key_secret')?.setting_value

    // Create Razorpay order (simplified for demo)
    const razorpayOrder = {
      id: 'rzp_order_' + Date.now(),
      amount: amount * 100, // Convert to paise
      currency: 'INR',
      receipt: order_id,
      key_id: razorpay_key_id
    }

    return c.json({ 
      success: true, 
      order: razorpayOrder 
    })
  } catch (error) {
    console.error('Error creating Razorpay order:', error)
    return c.json({ error: 'Failed to create payment' }, 500)
  }
})

// Verify Razorpay payment
paymentRoutes.post('/razorpay/verify', async (c) => {
  const { env } = c
  const { razorpay_payment_id, razorpay_order_id, razorpay_signature, order_number } = await c.req.json()

  try {
    // Get Razorpay secret
    const secretResult = await env.DB.prepare(
      'SELECT setting_value FROM site_settings WHERE setting_key = "razorpay_key_secret"'
    ).first()

    const secret = secretResult?.setting_value || ''

    // Verify signature using Web Crypto API
    const generated_signature = await createHmacSignature(
      secret,
      razorpay_order_id + '|' + razorpay_payment_id
    )

    if (generated_signature === razorpay_signature) {
      // Update order payment status
      await env.DB.prepare(
        `UPDATE orders 
         SET payment_status = 'paid', 
             payment_id = ?, 
             transaction_id = ?,
             status = 'processing'
         WHERE order_number = ?`
      ).bind(razorpay_payment_id, razorpay_order_id, order_number).run()

      return c.json({ success: true, message: 'Payment verified successfully' })
    } else {
      return c.json({ error: 'Invalid payment signature' }, 400)
    }
  } catch (error) {
    console.error('Error verifying payment:', error)
    return c.json({ error: 'Payment verification failed' }, 500)
  }
})

// Initialize PhonePe payment
paymentRoutes.post('/phonepe/create', async (c) => {
  const { env } = c
  const { order_id, amount, mobile } = await c.req.json()

  try {
    // Get PhonePe credentials from settings
    const settings = await env.DB.prepare(
      `SELECT setting_key, setting_value FROM site_settings 
       WHERE setting_key IN ('phonepe_merchant_id', 'phonepe_salt_key', 'phonepe_salt_index')`
    ).all()

    const merchant_id = settings.results?.find((s: any) => s.setting_key === 'phonepe_merchant_id')?.setting_value
    const salt_key = settings.results?.find((s: any) => s.setting_key === 'phonepe_salt_key')?.setting_value
    const salt_index = settings.results?.find((s: any) => s.setting_key === 'phonepe_salt_index')?.setting_value

    // Create PhonePe payment request (simplified for demo)
    const transactionId = 'TXN' + Date.now()
    
    const payload = {
      merchantId: merchant_id,
      merchantTransactionId: transactionId,
      merchantUserId: mobile,
      amount: amount * 100, // Convert to paise
      redirectUrl: `${c.req.url.origin}/api/payment/phonepe/callback`,
      redirectMode: 'POST',
      callbackUrl: `${c.req.url.origin}/api/payment/phonepe/callback`,
      mobileNumber: mobile,
      paymentInstrument: {
        type: 'PAY_PAGE'
      }
    }

    const base64Payload = btoa(JSON.stringify(payload))
    const checksum = await sha256Hash(base64Payload + '/pg/v1/pay' + salt_key) + '###' + salt_index

    return c.json({
      success: true,
      payment_url: `https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay`,
      payload: base64Payload,
      checksum,
      transaction_id: transactionId
    })
  } catch (error) {
    console.error('Error creating PhonePe payment:', error)
    return c.json({ error: 'Failed to create payment' }, 500)
  }
})

// PhonePe callback
paymentRoutes.post('/phonepe/callback', async (c) => {
  const { env } = c
  const body = await c.req.json()

  try {
    // Verify PhonePe callback (simplified)
    const { code, merchantTransactionId, transactionId } = body

    if (code === 'PAYMENT_SUCCESS') {
      // Update order payment status
      await env.DB.prepare(
        `UPDATE orders 
         SET payment_status = 'paid', 
             payment_id = ?, 
             transaction_id = ?,
             status = 'processing'
         WHERE order_number LIKE ?`
      ).bind(merchantTransactionId, transactionId, '%' + merchantTransactionId.replace('TXN', '')).run()

      return c.json({ success: true })
    } else {
      return c.json({ error: 'Payment failed' }, 400)
    }
  } catch (error) {
    console.error('Error processing PhonePe callback:', error)
    return c.json({ error: 'Callback processing failed' }, 500)
  }
})

// COD (Cash on Delivery) order confirmation
paymentRoutes.post('/cod/confirm', async (c) => {
  const { env } = c
  const { order_number } = await c.req.json()

  try {
    await env.DB.prepare(
      `UPDATE orders 
       SET payment_status = 'cod', 
           status = 'processing'
       WHERE order_number = ?`
    ).bind(order_number).run()

    return c.json({ success: true, message: 'COD order confirmed' })
  } catch (error) {
    console.error('Error confirming COD order:', error)
    return c.json({ error: 'Failed to confirm order' }, 500)
  }
})

export { paymentRoutes }