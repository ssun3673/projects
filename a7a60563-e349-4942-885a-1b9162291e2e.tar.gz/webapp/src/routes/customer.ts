import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'

const customerRoutes = new Hono()

// Get customer profile
customerRoutes.get('/profile/:id', authMiddleware, async (c) => {
  const { env } = c
  const customer_id = c.req.param('id')

  try {
    const customer = await env.DB.prepare(
      'SELECT id, first_name, last_name, email, phone, profile_image, newsletter_subscription FROM customers WHERE id = ?'
    ).bind(customer_id).first()

    if (!customer) {
      return c.json({ error: 'Customer not found' }, 404)
    }

    return c.json({ customer })
  } catch (error) {
    console.error('Error fetching profile:', error)
    return c.json({ error: 'Failed to fetch profile' }, 500)
  }
})

// Update customer profile
customerRoutes.put('/profile/:id', authMiddleware, async (c) => {
  const { env } = c
  const customer_id = c.req.param('id')
  const updates = await c.req.json()

  try {
    const updateFields = []
    const values = []

    // Build dynamic update query
    Object.keys(updates).forEach(key => {
      if (['first_name', 'last_name', 'phone', 'date_of_birth', 'gender'].includes(key)) {
        updateFields.push(`${key} = ?`)
        values.push(updates[key])
      }
    })

    if (updateFields.length > 0) {
      values.push(customer_id)
      await env.DB.prepare(
        `UPDATE customers SET ${updateFields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
      ).bind(...values).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating profile:', error)
    return c.json({ error: 'Failed to update profile' }, 500)
  }
})

// Get customer addresses
customerRoutes.get('/addresses/:customer_id', authMiddleware, async (c) => {
  const { env } = c
  const customer_id = c.req.param('customer_id')

  try {
    const addresses = await env.DB.prepare(
      'SELECT * FROM customer_addresses WHERE customer_id = ? ORDER BY is_default DESC, created_at DESC'
    ).bind(customer_id).all()

    return c.json({ addresses: addresses.results })
  } catch (error) {
    console.error('Error fetching addresses:', error)
    return c.json({ error: 'Failed to fetch addresses' }, 500)
  }
})

// Add new address
customerRoutes.post('/addresses', authMiddleware, async (c) => {
  const { env } = c
  const address = await c.req.json()

  try {
    // If setting as default, unset other defaults
    if (address.is_default) {
      await env.DB.prepare(
        'UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?'
      ).bind(address.customer_id).run()
    }

    const result = await env.DB.prepare(
      `INSERT INTO customer_addresses (
        customer_id, type, is_default, full_name, phone,
        address_line_1, address_line_2, city, state, postal_code, country, landmark
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      address.customer_id,
      address.type || 'shipping',
      address.is_default || 0,
      address.full_name,
      address.phone,
      address.address_line_1,
      address.address_line_2 || null,
      address.city,
      address.state,
      address.postal_code,
      address.country || 'India',
      address.landmark || null
    ).run()

    return c.json({ success: true, address_id: result.meta.last_row_id })
  } catch (error) {
    console.error('Error adding address:', error)
    return c.json({ error: 'Failed to add address' }, 500)
  }
})

// Update address
customerRoutes.put('/addresses/:id', authMiddleware, async (c) => {
  const { env } = c
  const address_id = c.req.param('id')
  const updates = await c.req.json()

  try {
    // If setting as default, unset other defaults
    if (updates.is_default) {
      const currentAddress = await env.DB.prepare(
        'SELECT customer_id FROM customer_addresses WHERE id = ?'
      ).bind(address_id).first()

      await env.DB.prepare(
        'UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?'
      ).bind(currentAddress.customer_id).run()
    }

    const updateFields = []
    const values = []

    Object.keys(updates).forEach(key => {
      if (['full_name', 'phone', 'address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'landmark', 'is_default'].includes(key)) {
        updateFields.push(`${key} = ?`)
        values.push(updates[key])
      }
    })

    if (updateFields.length > 0) {
      values.push(address_id)
      await env.DB.prepare(
        `UPDATE customer_addresses SET ${updateFields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
      ).bind(...values).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating address:', error)
    return c.json({ error: 'Failed to update address' }, 500)
  }
})

// Delete address
customerRoutes.delete('/addresses/:id', authMiddleware, async (c) => {
  const { env } = c
  const address_id = c.req.param('id')

  try {
    await env.DB.prepare(
      'DELETE FROM customer_addresses WHERE id = ?'
    ).bind(address_id).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error deleting address:', error)
    return c.json({ error: 'Failed to delete address' }, 500)
  }
})

// Get wishlist
customerRoutes.get('/wishlist/:customer_id', async (c) => {
  const { env } = c
  const customer_id = c.req.param('customer_id')

  try {
    const wishlist = await env.DB.prepare(
      `SELECT w.*, p.name, p.slug, p.price, p.sale_price, p.images 
       FROM wishlist_items w
       JOIN products p ON w.product_id = p.id
       WHERE w.customer_id = ?
       ORDER BY w.created_at DESC`
    ).bind(customer_id).all()

    return c.json({ wishlist: wishlist.results })
  } catch (error) {
    console.error('Error fetching wishlist:', error)
    return c.json({ error: 'Failed to fetch wishlist' }, 500)
  }
})

// Add to wishlist
customerRoutes.post('/wishlist', authMiddleware, async (c) => {
  const { env } = c
  const { customer_id, product_id } = await c.req.json()

  try {
    await env.DB.prepare(
      'INSERT OR IGNORE INTO wishlist_items (customer_id, product_id) VALUES (?, ?)'
    ).bind(customer_id, product_id).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error adding to wishlist:', error)
    return c.json({ error: 'Failed to add to wishlist' }, 500)
  }
})

// Remove from wishlist
customerRoutes.delete('/wishlist/:customer_id/:product_id', authMiddleware, async (c) => {
  const { env } = c
  const customer_id = c.req.param('customer_id')
  const product_id = c.req.param('product_id')

  try {
    await env.DB.prepare(
      'DELETE FROM wishlist_items WHERE customer_id = ? AND product_id = ?'
    ).bind(customer_id, product_id).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error removing from wishlist:', error)
    return c.json({ error: 'Failed to remove from wishlist' }, 500)
  }
})

export { customerRoutes }