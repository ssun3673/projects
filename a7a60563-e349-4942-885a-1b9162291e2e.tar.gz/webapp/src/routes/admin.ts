import { Hono } from 'hono'
import { adminMiddleware } from '../middleware/auth'

const adminRoutes = new Hono()

// Apply admin middleware to all routes
adminRoutes.use('*', adminMiddleware)

// Dashboard stats
adminRoutes.get('/dashboard', async (c) => {
  const { env } = c

  try {
    // Get various stats
    const stats = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as total FROM orders WHERE DATE(created_at) = DATE("now")').first(),
      env.DB.prepare('SELECT SUM(total_amount) as revenue FROM orders WHERE payment_status = "paid" AND DATE(created_at) = DATE("now")').first(),
      env.DB.prepare('SELECT COUNT(*) as total FROM customers').first(),
      env.DB.prepare('SELECT COUNT(*) as total FROM products WHERE status = "active"').first(),
      env.DB.prepare('SELECT COUNT(*) as pending FROM orders WHERE status = "pending"').first(),
      env.DB.prepare('SELECT COUNT(*) as low_stock FROM products WHERE quantity < min_quantity').first()
    ])

    const recentOrders = await env.DB.prepare(
      'SELECT * FROM orders ORDER BY created_at DESC LIMIT 10'
    ).all()

    return c.json({
      stats: {
        todayOrders: stats[0]?.total || 0,
        todayRevenue: stats[1]?.revenue || 0,
        totalCustomers: stats[2]?.total || 0,
        activeProducts: stats[3]?.total || 0,
        pendingOrders: stats[4]?.pending || 0,
        lowStockProducts: stats[5]?.low_stock || 0
      },
      recentOrders: recentOrders.results
    })
  } catch (error) {
    console.error('Dashboard error:', error)
    return c.json({ error: 'Failed to fetch dashboard data' }, 500)
  }
})

// Product Management
adminRoutes.get('/products', async (c) => {
  const { env } = c
  const { page = '1', limit = '20', search, category, status } = c.req.query()

  try {
    let query = 'SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE 1=1'
    const params: any[] = []

    if (search) {
      query += ' AND (p.name LIKE ? OR p.sku LIKE ?)'
      params.push(`%${search}%`, `%${search}%`)
    }

    if (category) {
      query += ' AND p.category_id = ?'
      params.push(category)
    }

    if (status) {
      query += ' AND p.status = ?'
      params.push(status)
    }

    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?'
    params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit))

    const products = await env.DB.prepare(query).bind(...params).all()

    return c.json({ products: products.results })
  } catch (error) {
    console.error('Error fetching products:', error)
    return c.json({ error: 'Failed to fetch products' }, 500)
  }
})

// Add/Update Product
adminRoutes.post('/products', async (c) => {
  const { env } = c
  const product = await c.req.json()
  const admin = c.get('admin')

  try {
    if (product.id) {
      // Update existing product
      await env.DB.prepare(
        `UPDATE products SET 
         name = ?, slug = ?, description = ?, short_description = ?,
         category_id = ?, price = ?, sale_price = ?, quantity = ?,
         material = ?, color = ?, featured = ?, is_new = ?, status = ?,
         images = ?, specifications = ?, meta_title = ?, meta_description = ?, meta_keywords = ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(
        product.name, product.slug, product.description, product.short_description,
        product.category_id, product.price, product.sale_price, product.quantity,
        product.material, product.color, product.featured ? 1 : 0, product.is_new ? 1 : 0, product.status,
        JSON.stringify(product.images), JSON.stringify(product.specifications),
        product.meta_title, product.meta_description, product.meta_keywords,
        product.id
      ).run()

      return c.json({ success: true, message: 'Product updated' })
    } else {
      // Create new product
      const result = await env.DB.prepare(
        `INSERT INTO products (
         sku, name, slug, description, short_description, category_id,
         price, sale_price, quantity, material, color, featured, is_new, status,
         images, specifications, meta_title, meta_description, meta_keywords, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        product.sku, product.name, product.slug, product.description, product.short_description,
        product.category_id, product.price, product.sale_price, product.quantity,
        product.material, product.color, product.featured ? 1 : 0, product.is_new ? 1 : 0, product.status,
        JSON.stringify(product.images), JSON.stringify(product.specifications),
        product.meta_title, product.meta_description, product.meta_keywords, admin.id
      ).run()

      return c.json({ success: true, product_id: result.meta.last_row_id })
    }
  } catch (error) {
    console.error('Error saving product:', error)
    return c.json({ error: 'Failed to save product' }, 500)
  }
})

// Delete Product
adminRoutes.delete('/products/:id', async (c) => {
  const { env } = c
  const product_id = c.req.param('id')

  try {
    await env.DB.prepare('UPDATE products SET status = "inactive" WHERE id = ?').bind(product_id).run()
    return c.json({ success: true })
  } catch (error) {
    console.error('Error deleting product:', error)
    return c.json({ error: 'Failed to delete product' }, 500)
  }
})

// Order Management
adminRoutes.get('/orders', async (c) => {
  const { env } = c
  const { page = '1', limit = '20', status, search } = c.req.query()

  try {
    let query = 'SELECT o.*, c.first_name, c.last_name FROM orders o LEFT JOIN customers c ON o.customer_id = c.id WHERE 1=1'
    const params: any[] = []

    if (status) {
      query += ' AND o.status = ?'
      params.push(status)
    }

    if (search) {
      query += ' AND (o.order_number LIKE ? OR c.email LIKE ?)'
      params.push(`%${search}%`, `%${search}%`)
    }

    query += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?'
    params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit))

    const orders = await env.DB.prepare(query).bind(...params).all()

    return c.json({ orders: orders.results })
  } catch (error) {
    console.error('Error fetching orders:', error)
    return c.json({ error: 'Failed to fetch orders' }, 500)
  }
})

// Update Order Status
adminRoutes.put('/orders/:id/status', async (c) => {
  const { env } = c
  const order_id = c.req.param('id')
  const { status, tracking_number } = await c.req.json()

  try {
    let updateQuery = 'UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP'
    const params = [status]

    if (status === 'shipped' && tracking_number) {
      updateQuery += ', tracking_number = ?, shipped_at = CURRENT_TIMESTAMP'
      params.push(tracking_number)
    } else if (status === 'delivered') {
      updateQuery += ', delivered_at = CURRENT_TIMESTAMP'
    } else if (status === 'cancelled') {
      updateQuery += ', cancelled_at = CURRENT_TIMESTAMP'
    }

    updateQuery += ' WHERE id = ?'
    params.push(order_id)

    await env.DB.prepare(updateQuery).bind(...params).run()

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating order:', error)
    return c.json({ error: 'Failed to update order' }, 500)
  }
})

// Site Settings Management
adminRoutes.get('/settings', async (c) => {
  const { env } = c

  try {
    const settings = await env.DB.prepare('SELECT * FROM site_settings ORDER BY category, setting_key').all()
    
    // Group by category
    const grouped = settings.results?.reduce((acc: any, setting: any) => {
      if (!acc[setting.category]) acc[setting.category] = []
      acc[setting.category].push(setting)
      return acc
    }, {})

    return c.json({ settings: grouped })
  } catch (error) {
    console.error('Error fetching settings:', error)
    return c.json({ error: 'Failed to fetch settings' }, 500)
  }
})

// Update Site Settings
adminRoutes.put('/settings', async (c) => {
  const { env } = c
  const updates = await c.req.json()
  const admin = c.get('admin')

  try {
    for (const key in updates) {
      await env.DB.prepare(
        `INSERT INTO site_settings (setting_key, setting_value, updated_by) 
         VALUES (?, ?, ?)
         ON CONFLICT(setting_key) DO UPDATE SET 
         setting_value = excluded.setting_value,
         updated_by = excluded.updated_by,
         updated_at = CURRENT_TIMESTAMP`
      ).bind(key, updates[key], admin.id).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating settings:', error)
    return c.json({ error: 'Failed to update settings' }, 500)
  }
})

// Category Management
adminRoutes.get('/categories', async (c) => {
  const { env } = c

  try {
    const categories = await env.DB.prepare(
      'SELECT * FROM categories ORDER BY parent_id, sort_order, name'
    ).all()

    return c.json({ categories: categories.results })
  } catch (error) {
    console.error('Error fetching categories:', error)
    return c.json({ error: 'Failed to fetch categories' }, 500)
  }
})

// Add/Update Category
adminRoutes.post('/categories', async (c) => {
  const { env } = c
  const category = await c.req.json()
  const admin = c.get('admin')

  try {
    if (category.id) {
      // Update
      await env.DB.prepare(
        `UPDATE categories SET 
         name = ?, slug = ?, description = ?, parent_id = ?, image_url = ?,
         meta_title = ?, meta_description = ?, meta_keywords = ?, is_active = ?, sort_order = ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(
        category.name, category.slug, category.description, category.parent_id,
        category.image_url, category.meta_title, category.meta_description,
        category.meta_keywords, category.is_active ? 1 : 0, category.sort_order, category.id
      ).run()
    } else {
      // Create
      await env.DB.prepare(
        `INSERT INTO categories (
         name, slug, description, parent_id, image_url,
         meta_title, meta_description, meta_keywords, is_active, sort_order, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        category.name, category.slug, category.description, category.parent_id,
        category.image_url, category.meta_title, category.meta_description,
        category.meta_keywords, category.is_active ? 1 : 0, category.sort_order, admin.id
      ).run()
    }

    return c.json({ success: true })
  } catch (error) {
    console.error('Error saving category:', error)
    return c.json({ error: 'Failed to save category' }, 500)
  }
})

export { adminRoutes }