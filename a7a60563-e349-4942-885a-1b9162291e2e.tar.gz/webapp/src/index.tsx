import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'
import { serveStatic } from 'hono/cloudflare-workers'

// Import routes
import { adminRoutes } from './routes/admin'
import { authRoutes } from './routes/auth'
import { productRoutes } from './routes/products'
import { cartRoutes } from './routes/cart'
import { orderRoutes } from './routes/orders'
import { paymentRoutes } from './routes/payment'
import { customerRoutes } from './routes/customer'

// Import middleware
import { authMiddleware } from './middleware/auth'

// Type definitions for Cloudflare bindings
type Bindings = {
  DB: D1Database
  KV_SESSIONS: KVNamespace
  KV_CACHE: KVNamespace
  R2_UPLOADS: R2Bucket
  RAZORPAY_KEY_ID: string
  RAZORPAY_KEY_SECRET: string
  PHONEPE_MERCHANT_ID: string
  PHONEPE_SALT_KEY: string
}

const app = new Hono<{ Bindings: Bindings }>()

// Global middleware
app.use('*', logger())
app.use('/api/*', cors({
  origin: ['http://localhost:3000', 'https://om-modular.pages.dev'],
  credentials: true
}))

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))
app.use('/images/*', serveStatic({ root: './public' }))
app.use('/uploads/*', serveStatic({ root: './public' }))

// API Routes
app.route('/api/auth', authRoutes)
app.route('/api/admin', adminRoutes)
app.route('/api/products', productRoutes)
app.route('/api/cart', cartRoutes)
app.route('/api/orders', orderRoutes)
app.route('/api/payment', paymentRoutes)
app.route('/api/customer', customerRoutes)

// Health check
app.get('/api/health', (c) => {
  return c.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    service: 'Om Modular Furniture API'
  })
})

// Main website route
app.get('/', async (c) => {
  const { env } = c
  
  // Fetch site settings from database
  let siteSettings: any = {}
  try {
    const settings = await env.DB.prepare('SELECT setting_key, setting_value FROM site_settings').all()
    settings.results?.forEach((setting: any) => {
      siteSettings[setting.setting_key] = setting.setting_value
    })
  } catch (error) {
    console.error('Error fetching settings:', error)
  }

  return c.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${siteSettings.site_name || 'Om Modular Araria'} - Premium Modular Furniture</title>
    <meta name="description" content="${siteSettings.seo_description || 'Shop premium quality modular furniture at Om Modular Araria'}">
    <meta name="keywords" content="${siteSettings.seo_keywords || 'modular furniture, furniture store'}">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome Icons -->
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="/static/styles.css" rel="stylesheet">
    
    <!-- Theme Colors Configuration -->
    <style>
        :root {
            --primary-black: #000000;
            --primary-blue: #0066cc;
            --primary-white: #ffffff;
            --primary-pink: #ff1493;
            --text-dark: #333333;
            --text-light: #666666;
            --border-color: #e0e0e0;
        }
        
        .bg-gradient-custom {
            background: linear-gradient(135deg, var(--primary-blue), var(--primary-pink));
        }
        
        .text-gradient {
            background: linear-gradient(135deg, var(--primary-blue), var(--primary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-white">
    <!-- Three Header Layout -->
    
    <!-- Header 1: Top Offer Bar -->
    <div class="bg-black text-white py-2 px-4 text-center text-sm">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex-1 text-left">
                <i class="fas fa-truck mr-2"></i>
                <span>Free Delivery on Orders Above ₹5000</span>
            </div>
            <div class="flex-1 text-center font-bold">
                <i class="fas fa-tag mr-2 text-pink-500"></i>
                <span>${siteSettings.current_offer || 'Flat 20% OFF on All Furniture - Limited Time!'}</span>
            </div>
            <div class="flex-1 text-right">
                <i class="fas fa-phone mr-2"></i>
                <span>${siteSettings.contact_phone || '+91 9876543210'}</span>
            </div>
        </div>
    </div>
    
    <!-- Header 2: Main Header with Logo and Search -->
    <header class="bg-white border-b border-gray-200 py-4">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between">
                <!-- Logo -->
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <div class="bg-blue-600 text-white p-3 rounded-lg mr-3">
                            <i class="fas fa-couch text-2xl"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-black">OM MODULAR</h1>
                            <p class="text-sm text-gray-600">ARARIA</p>
                        </div>
                    </a>
                </div>
                
                <!-- Search Bar -->
                <div class="flex-1 max-w-xl mx-8">
                    <form class="relative" onsubmit="searchProducts(event)">
                        <input type="text" 
                               id="search_input"
                               placeholder="Search for furniture, sofas, beds..." 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                        <button type="submit" class="absolute right-2 top-2 text-blue-600 hover:text-blue-800">
                            <i class="fas fa-search text-xl"></i>
                        </button>
                    </form>
                </div>
                
                <!-- User Actions -->
                <div class="flex items-center space-x-6">
                    <button onclick="toggleLogin()" class="flex flex-col items-center text-gray-700 hover:text-blue-600">
                        <i class="fas fa-user text-xl mb-1"></i>
                        <span class="text-xs">Account</span>
                    </button>
                    <button onclick="toggleWishlist()" class="flex flex-col items-center text-gray-700 hover:text-blue-600 relative">
                        <i class="fas fa-heart text-xl mb-1"></i>
                        <span class="text-xs">Wishlist</span>
                        <span class="absolute -top-1 -right-2 bg-pink-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">0</span>
                    </button>
                    <button onclick="toggleCart()" class="flex flex-col items-center text-gray-700 hover:text-blue-600 relative">
                        <i class="fas fa-shopping-cart text-xl mb-1"></i>
                        <span class="text-xs">Cart</span>
                        <span class="absolute -top-1 -right-2 bg-blue-600 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">0</span>
                    </button>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Header 3: Navigation Menu -->
    <nav class="bg-blue-600 text-white py-3 sticky top-0 z-40 shadow-md">
        <div class="container mx-auto px-4">
            <ul class="flex items-center space-x-8">
                <li><a href="/" class="hover:text-pink-300 transition font-medium">Home</a></li>
                <li class="relative group">
                    <button class="hover:text-pink-300 transition font-medium flex items-center">
                        Categories <i class="fas fa-chevron-down ml-1 text-xs"></i>
                    </button>
                    <div class="absolute left-0 mt-3 w-64 bg-white text-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                        <a href="/category/living-room" class="block px-4 py-3 hover:bg-gray-50 border-b">
                            <i class="fas fa-couch mr-2 text-blue-600"></i> Living Room
                        </a>
                        <a href="/category/bedroom" class="block px-4 py-3 hover:bg-gray-50 border-b">
                            <i class="fas fa-bed mr-2 text-blue-600"></i> Bedroom
                        </a>
                        <a href="/category/dining-room" class="block px-4 py-3 hover:bg-gray-50 border-b">
                            <i class="fas fa-utensils mr-2 text-blue-600"></i> Dining Room
                        </a>
                        <a href="/category/office" class="block px-4 py-3 hover:bg-gray-50 border-b">
                            <i class="fas fa-briefcase mr-2 text-blue-600"></i> Office Furniture
                        </a>
                        <a href="/category/kitchen" class="block px-4 py-3 hover:bg-gray-50 border-b">
                            <i class="fas fa-blender mr-2 text-blue-600"></i> Kitchen
                        </a>
                        <a href="/category/kids" class="block px-4 py-3 hover:bg-gray-50">
                            <i class="fas fa-child mr-2 text-blue-600"></i> Kids Furniture
                        </a>
                    </div>
                </li>
                <li><a href="/new_arrivals" class="hover:text-pink-300 transition font-medium">New Arrivals</a></li>
                <li><a href="/sale" class="hover:text-pink-300 transition font-medium text-pink-300">
                    <i class="fas fa-fire mr-1"></i> Sale
                </a></li>
                <li><a href="/collections" class="hover:text-pink-300 transition font-medium">Collections</a></li>
                <li><a href="/custom_furniture" class="hover:text-pink-300 transition font-medium">Custom Furniture</a></li>
                <li><a href="/about" class="hover:text-pink-300 transition font-medium">About Us</a></li>
                <li><a href="/contact" class="hover:text-pink-300 transition font-medium">Contact</a></li>
            </ul>
        </div>
    </nav>
    
    <!-- Main Content Area -->
    <main id="main_content">
        <!-- Hero Section with Slider -->
        <section class="relative h-96 bg-gray-100">
            <div id="hero_slider" class="h-full">
                <!-- Slides will be loaded dynamically -->
            </div>
        </section>
        
        <!-- Featured Categories -->
        <section class="py-12 bg-gray-50">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl font-bold text-center mb-8">Shop by Category</h2>
                <div id="category_grid" class="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <!-- Categories will be loaded dynamically -->
                </div>
            </div>
        </section>
        
        <!-- Featured Products -->
        <section class="py-12">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl font-bold text-center mb-8">Featured Products</h2>
                <div id="featured_products" class="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <!-- Products will be loaded dynamically -->
                </div>
            </div>
        </section>
        
        <!-- Why Choose Us -->
        <section class="py-12 bg-blue-50">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl font-bold text-center mb-8">Why Choose Om Modular?</h2>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div class="text-center">
                        <div class="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-medal text-3xl"></i>
                        </div>
                        <h3 class="font-bold mb-2">Premium Quality</h3>
                        <p class="text-gray-600">High-quality materials and craftsmanship</p>
                    </div>
                    <div class="text-center">
                        <div class="bg-pink-500 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-truck text-3xl"></i>
                        </div>
                        <h3 class="font-bold mb-2">Free Delivery</h3>
                        <p class="text-gray-600">Free delivery on orders above ₹5000</p>
                    </div>
                    <div class="text-center">
                        <div class="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-tools text-3xl"></i>
                        </div>
                        <h3 class="font-bold mb-2">Free Installation</h3>
                        <p class="text-gray-600">Professional installation at no extra cost</p>
                    </div>
                    <div class="text-center">
                        <div class="bg-pink-500 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-shield-alt text-3xl"></i>
                        </div>
                        <h3 class="font-bold mb-2">Warranty</h3>
                        <p class="text-gray-600">Comprehensive warranty on all products</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <!-- Footer -->
    <footer class="bg-black text-white pt-12 pb-6">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <!-- Company Info -->
                <div>
                    <div class="flex items-center mb-4">
                        <div class="bg-blue-600 text-white p-2 rounded-lg mr-3">
                            <i class="fas fa-couch text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold">OM MODULAR</h3>
                            <p class="text-sm text-gray-400">ARARIA</p>
                        </div>
                    </div>
                    <p class="text-gray-400 mb-4">Premium modular furniture for modern living. Quality, comfort, and style combined.</p>
                    <div class="flex space-x-4">
                        <a href="${siteSettings.facebook_url || '#'}" class="text-gray-400 hover:text-white"><i class="fab fa-facebook text-xl"></i></a>
                        <a href="${siteSettings.instagram_url || '#'}" class="text-gray-400 hover:text-white"><i class="fab fa-instagram text-xl"></i></a>
                        <a href="${siteSettings.twitter_url || '#'}" class="text-gray-400 hover:text-white"><i class="fab fa-twitter text-xl"></i></a>
                        <a href="${siteSettings.youtube_url || '#'}" class="text-gray-400 hover:text-white"><i class="fab fa-youtube text-xl"></i></a>
                        <a href="https://wa.me/${siteSettings.whatsapp_number?.replace(/[^0-9]/g, '') || '919876543210'}" class="text-gray-400 hover:text-white">
                            <i class="fab fa-whatsapp text-xl"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h4 class="text-lg font-bold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="/about" class="text-gray-400 hover:text-white">About Us</a></li>
                        <li><a href="/products" class="text-gray-400 hover:text-white">All Products</a></li>
                        <li><a href="/offers" class="text-gray-400 hover:text-white">Offers & Deals</a></li>
                        <li><a href="/custom_furniture" class="text-gray-400 hover:text-white">Custom Furniture</a></li>
                        <li><a href="/careers" class="text-gray-400 hover:text-white text-pink-400">
                            <i class="fas fa-briefcase mr-1"></i> Careers
                        </a></li>
                    </ul>
                </div>
                
                <!-- Customer Service -->
                <div>
                    <h4 class="text-lg font-bold mb-4">Customer Service</h4>
                    <ul class="space-y-2">
                        <li><a href="/contact" class="text-gray-400 hover:text-white">Contact Support</a></li>
                        <li><a href="/track_order" class="text-gray-400 hover:text-white">Track Order</a></li>
                        <li><a href="/shipping" class="text-gray-400 hover:text-white">Shipping Info</a></li>
                        <li><a href="/returns" class="text-gray-400 hover:text-white">Returns & Exchange</a></li>
                        <li><a href="/warranty" class="text-gray-400 hover:text-white">Warranty</a></li>
                        <li><a href="/faq" class="text-gray-400 hover:text-white">FAQ</a></li>
                    </ul>
                </div>
                
                <!-- Contact Info -->
                <div>
                    <h4 class="text-lg font-bold mb-4">Contact Us</h4>
                    <ul class="space-y-3 text-gray-400">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mr-3 mt-1 text-pink-500"></i>
                            <span>${siteSettings.contact_address || 'Main Road, Araria, Bihar - 854311'}</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone mr-3 text-pink-500"></i>
                            <a href="tel:${siteSettings.contact_phone?.replace(/[^0-9+]/g, '') || '+919876543210'}" class="hover:text-white">
                                ${siteSettings.contact_phone || '+91 9876543210'}
                            </a>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-3 text-pink-500"></i>
                            <a href="mailto:${siteSettings.contact_email || 'info@ommodularararia.com'}" class="hover:text-white">
                                ${siteSettings.contact_email || 'info@ommodularararia.com'}
                            </a>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-clock mr-3 mt-1 text-pink-500"></i>
                            <span>${siteSettings.business_hours || 'Mon-Sat: 10 AM - 8 PM'}</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Payment Methods & Copyright -->
            <div class="border-t border-gray-800 pt-6">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="mb-4 md:mb-0">
                        <p class="text-sm text-gray-400">Secure Payments:</p>
                        <div class="flex items-center space-x-4 mt-2">
                            <i class="fas fa-credit-card text-2xl text-gray-500"></i>
                            <span class="text-blue-500 font-bold">Razorpay</span>
                            <span class="text-green-500 font-bold">PhonePe</span>
                            <span class="text-gray-500">Cash on Delivery</span>
                        </div>
                    </div>
                    <div class="text-center md:text-right">
                        <p class="text-sm text-gray-400">
                            © 2024 Om Modular Araria. All rights reserved.
                        </p>
                        <p class="text-xs text-gray-500 mt-1">
                            <a href="/privacy" class="hover:text-white">Privacy Policy</a> | 
                            <a href="/terms" class="hover:text-white">Terms & Conditions</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Admin Panel Link (Hidden, access via /admin) -->
    <div id="admin_link" class="fixed bottom-4 right-4 z-50 hidden">
        <a href="/admin" class="bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700">
            <i class="fas fa-cog"></i>
        </a>
    </div>
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="/static/main.js"></script>
    
    <!-- Initialize -->
    <script>
        // Load initial data
        document.addEventListener('DOMContentLoaded', function() {
            loadHomepageData();
            checkUserSession();
            updateCartCount();
        });
    </script>
</body>
</html>
  `)
})

// Admin Panel Route
app.get('/admin', (c) => {
  return c.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Om Modular Araria</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/static/admin.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div id="admin_app">
        <!-- Admin panel will be loaded here -->
    </div>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="/static/admin.js"></script>
</body>
</html>
  `)
})

// Catch-all for SPA routes
app.get('*', (c) => {
  return c.redirect('/')
})

export default app