-- Insert default admin user (password: admin123)
INSERT OR IGNORE INTO admin_users (username, email, password_hash, full_name, role) 
VALUES ('admin', 'admin@ommodularararia.com', '$2a$10$YourHashedPasswordHere', 'Admin User', 'super_admin');

-- Insert default site settings
INSERT OR IGNORE INTO site_settings (setting_key, setting_value, setting_type, category) VALUES
('site_name', 'Om Modular Araria', 'text', 'general'),
('site_tagline', 'Premium Modular Furniture for Modern Living', 'text', 'general'),
('site_logo', '/images/logo.png', 'image', 'general'),
('site_favicon', '/images/favicon.ico', 'image', 'general'),
('contact_email', 'info@ommodularararia.com', 'text', 'general'),
('contact_phone', '+91 9876543210', 'text', 'general'),
('contact_address', 'Main Road, Araria, Bihar - 854311', 'text', 'general'),
('business_hours', 'Mon-Sat: 10:00 AM - 8:00 PM, Sun: 11:00 AM - 6:00 PM', 'text', 'general'),
('gst_number', 'GSTIN1234567890', 'text', 'general'),
('facebook_url', 'https://facebook.com/ommodularararia', 'text', 'social'),
('instagram_url', 'https://instagram.com/ommodularararia', 'text', 'social'),
('twitter_url', 'https://twitter.com/ommodularararia', 'text', 'social'),
('youtube_url', 'https://youtube.com/ommodularararia', 'text', 'social'),
('whatsapp_number', '+919876543210', 'text', 'social'),
('razorpay_key_id', 'rzp_test_1234567890', 'text', 'payment'),
('razorpay_key_secret', 'secret_key_here', 'text', 'payment'),
('phonepe_merchant_id', 'MERCHANTUAT', 'text', 'payment'),
('phonepe_salt_key', 'salt_key_here', 'text', 'payment'),
('phonepe_salt_index', '1', 'text', 'payment'),
('hostinger_smtp_host', 'smtp.hostinger.com', 'text', 'email'),
('hostinger_smtp_port', '587', 'text', 'email'),
('hostinger_smtp_user', 'noreply@ommodularararia.com', 'text', 'email'),
('hostinger_smtp_password', 'email_password_here', 'text', 'email'),
('seo_title', 'Om Modular Araria - Premium Modular Furniture Store', 'text', 'seo'),
('seo_description', 'Shop premium quality modular furniture at Om Modular Araria. Best prices on sofas, beds, wardrobes, dining sets, and office furniture. Free delivery in Araria.', 'text', 'seo'),
('seo_keywords', 'modular furniture, furniture store araria, sofa, bed, wardrobe, dining table, office furniture, home decor', 'text', 'seo'),
('google_analytics_id', 'UA-XXXXXXXXX-X', 'text', 'seo'),
('facebook_pixel_id', 'XXXXXXXXXXXXXXX', 'text', 'seo'),
('free_shipping_threshold', '5000', 'text', 'general'),
('tax_rate', '18', 'text', 'general'),
('currency_symbol', '₹', 'text', 'general'),
('current_offer', 'Flat 20% OFF on All Furniture - Limited Time!', 'text', 'general');

-- Insert categories
INSERT OR IGNORE INTO categories (name, slug, description, sort_order, is_active) VALUES
('Living Room', 'living-room', 'Elegant furniture for your living space', 1, 1),
('Bedroom', 'bedroom', 'Comfortable and stylish bedroom furniture', 2, 1),
('Dining Room', 'dining-room', 'Beautiful dining furniture sets', 3, 1),
('Office Furniture', 'office-furniture', 'Professional furniture for office spaces', 4, 1),
('Kitchen', 'kitchen', 'Modular kitchen cabinets and accessories', 5, 1),
('Kids Furniture', 'kids-furniture', 'Safe and colorful furniture for children', 6, 1),
('Outdoor', 'outdoor', 'Weather-resistant outdoor furniture', 7, 1),
('Storage & Organization', 'storage', 'Smart storage solutions', 8, 1);

-- Insert subcategories
INSERT OR IGNORE INTO categories (name, slug, description, parent_id, sort_order, is_active) VALUES
('Sofas', 'sofas', 'Comfortable and stylish sofas', 1, 1, 1),
('Coffee Tables', 'coffee-tables', 'Modern coffee tables', 1, 2, 1),
('TV Units', 'tv-units', 'Entertainment units and TV stands', 1, 3, 1),
('Beds', 'beds', 'Comfortable beds for good sleep', 2, 1, 1),
('Wardrobes', 'wardrobes', 'Spacious wardrobes and closets', 2, 2, 1),
('Dressing Tables', 'dressing-tables', 'Elegant dressing tables', 2, 3, 1),
('Dining Tables', 'dining-tables', 'Beautiful dining tables', 3, 1, 1),
('Dining Chairs', 'dining-chairs', 'Comfortable dining chairs', 3, 2, 1),
('Office Desks', 'office-desks', 'Professional office desks', 4, 1, 1),
('Office Chairs', 'office-chairs', 'Ergonomic office chairs', 4, 2, 1);

-- Insert sample products
INSERT OR IGNORE INTO products (
  sku, name, slug, description, short_description, 
  category_id, price, sale_price, quantity, 
  material, color, featured, is_new, status,
  images, specifications
) VALUES
('SOF001', 'Luxe 3-Seater Sofa', 'luxe-3-seater-sofa', 
 'Premium quality 3-seater sofa with high-density foam cushioning and Italian leather upholstery. Perfect for modern living rooms.',
 'Elegant 3-seater sofa with premium upholstery',
 9, 45000, 38000, 10,
 'Italian Leather', 'Brown', 1, 1, 'active',
 '["https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800"]',
 '{"dimensions": "200cm x 85cm x 90cm", "weight": "75kg", "warranty": "5 years", "seating": "3 persons"}'),

('BED001', 'King Size Storage Bed', 'king-size-storage-bed',
 'Spacious king size bed with hydraulic storage. Made from premium engineered wood with laminate finish.',
 'King size bed with built-in storage',
 12, 55000, 48000, 8,
 'Engineered Wood', 'Walnut', 1, 0, 'active',
 '["https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800"]',
 '{"dimensions": "180cm x 200cm", "storage": "Hydraulic", "mattress_size": "King", "warranty": "3 years"}'),

('WRD001', 'Modern 4-Door Wardrobe', 'modern-4-door-wardrobe',
 'Spacious 4-door wardrobe with mirror, multiple shelves, and hanging space. Perfect organization solution.',
 '4-door wardrobe with mirror and ample storage',
 13, 38000, 32000, 12,
 'Particle Board', 'White Oak', 1, 1, 'active',
 '["https://images.unsplash.com/photo-1595526114035-0d5ed5d6b8c5?w=800"]',
 '{"dimensions": "160cm x 60cm x 210cm", "doors": "4", "mirror": "Yes", "shelves": "8", "warranty": "2 years"}'),

('DIN001', 'Marble Top Dining Table 6-Seater', 'marble-dining-table-6',
 'Elegant dining table with genuine marble top and solid wood base. Seats 6 people comfortably.',
 'Luxury marble top dining table for 6',
 15, 75000, 68000, 5,
 'Marble & Solid Wood', 'White Marble', 1, 0, 'active',
 '["https://images.unsplash.com/photo-1549497538-303791108f95?w=800"]',
 '{"dimensions": "180cm x 90cm x 75cm", "seating": "6 persons", "top": "Italian Marble", "base": "Teak Wood"}'),

('OFF001', 'Executive Office Desk', 'executive-office-desk',
 'Premium executive desk with built-in cable management, drawers, and CPU storage.',
 'Professional executive desk with storage',
 17, 28000, 24000, 15,
 'Engineered Wood', 'Dark Walnut', 0, 1, 'active',
 '["https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=800"]',
 '{"dimensions": "150cm x 75cm x 75cm", "drawers": "3", "cable_management": "Yes", "warranty": "2 years"}'),

('CHA001', 'Ergonomic Office Chair', 'ergonomic-office-chair',
 'High-back ergonomic office chair with lumbar support, adjustable height, and breathable mesh back.',
 'Comfortable ergonomic office chair',
 18, 15000, 12500, 20,
 'Mesh & Plastic', 'Black', 0, 0, 'active',
 '["https://images.unsplash.com/photo-1592078615290-033ee584e267?w=800"]',
 '{"adjustable_height": "Yes", "lumbar_support": "Yes", "armrest": "3D Adjustable", "warranty": "1 year"}'),

('TV001', 'Modern TV Entertainment Unit', 'modern-tv-unit',
 'Stylish TV unit with ample storage space for up to 65" TV. Features cable management and display shelves.',
 'Contemporary TV unit with storage',
 11, 22000, 18500, 18,
 'Particle Board', 'Wenge', 0, 1, 'active',
 '["https://images.unsplash.com/photo-1571843439991-dd2b8e051966?w=800"]',
 '{"dimensions": "180cm x 40cm x 45cm", "max_tv_size": "65 inches", "shelves": "4", "warranty": "2 years"}'),

('COF001', 'Glass Top Coffee Table', 'glass-coffee-table',
 'Modern coffee table with tempered glass top and wooden base. Perfect centerpiece for living room.',
 'Elegant glass top coffee table',
 10, 18000, 15000, 25,
 'Glass & Wood', 'Clear & Brown', 0, 0, 'active',
 '["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800"]',
 '{"dimensions": "120cm x 60cm x 45cm", "glass": "8mm Tempered", "base": "Solid Wood", "warranty": "1 year"}');

-- Insert sample banners
INSERT OR IGNORE INTO banners (title, subtitle, image_url, link_url, button_text, position, sort_order, is_active) VALUES
('New Year Sale', 'Flat 20% OFF on All Furniture', 'https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=1920', '/offers', 'Shop Now', 'home', 1, 1),
('Premium Collection', 'Discover Luxury Living', 'https://images.unsplash.com/photo-1567538096630-e0c55bd29f9c?w=1920', '/collections/premium', 'Explore', 'home', 2, 1),
('Free Delivery', 'On Orders Above ₹5000', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920', '/products', 'Order Now', 'home', 3, 1);

-- Insert sample coupons
INSERT OR IGNORE INTO coupons (code, description, discount_type, discount_value, min_order_amount, is_active) VALUES
('WELCOME10', 'Welcome offer - 10% off on first order', 'percentage', 10, 2000, 1),
('FLAT500', 'Flat ₹500 off on orders above ₹10000', 'fixed', 500, 10000, 1),
('NEWYEAR20', 'New Year Special - 20% off', 'percentage', 20, 5000, 1);